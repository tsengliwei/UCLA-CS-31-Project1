﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Express 2012 for Windows Desktop
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "compile_error.cpp", "compile_error.cpp\compile_error.cpp.vcxproj", "{183AA318-7A2D-4D5E-AA3F-844E253ED72A}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Win32 = Debug|Win32
		Release|Win32 = Release|Win32
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{183AA318-7A2D-4D5E-AA3F-844E253ED72A}.Debug|Win32.ActiveCfg = Debug|Win32
		{183AA318-7A2D-4D5E-AA3F-844E253ED72A}.Debug|Win32.Build.0 = Debug|Win32
		{183AA318-7A2D-4D5E-AA3F-844E253ED72A}.Release|Win32.ActiveCfg = Release|Win32
		{183AA318-7A2D-4D5E-AA3F-844E253ED72A}.Release|Win32.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal
