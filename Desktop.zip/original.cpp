﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Express 2012 for Windows Desktop
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "original.cpp", "original.cpp\original.cpp.vcxproj", "{2FF68646-83C4-4615-A479-FD6DE4FE627D}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Win32 = Debug|Win32
		Release|Win32 = Release|Win32
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{2FF68646-83C4-4615-A479-FD6DE4FE627D}.Debug|Win32.ActiveCfg = Debug|Win32
		{2FF68646-83C4-4615-A479-FD6DE4FE627D}.Debug|Win32.Build.0 = Debug|Win32
		{2FF68646-83C4-4615-A479-FD6DE4FE627D}.Release|Win32.ActiveCfg = Release|Win32
		{2FF68646-83C4-4615-A479-FD6DE4FE627D}.Release|Win32.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal
