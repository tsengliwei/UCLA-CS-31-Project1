﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Express 2012 for Windows Desktop
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "logic_error.cpp", "logic_error.cpp\logic_error.cpp.vcxproj", "{9938B095-D144-4C5C-BE95-A51AC8BEB5D2}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Win32 = Debug|Win32
		Release|Win32 = Release|Win32
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{9938B095-D144-4C5C-BE95-A51AC8BEB5D2}.Debug|Win32.ActiveCfg = Debug|Win32
		{9938B095-D144-4C5C-BE95-A51AC8BEB5D2}.Debug|Win32.Build.0 = Debug|Win32
		{9938B095-D144-4C5C-BE95-A51AC8BEB5D2}.Release|Win32.ActiveCfg = Release|Win32
		{9938B095-D144-4C5C-BE95-A51AC8BEB5D2}.Release|Win32.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal
